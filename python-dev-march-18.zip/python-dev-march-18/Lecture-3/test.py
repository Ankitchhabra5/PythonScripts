from myfunc import mysum

print(mysum(3,2))

