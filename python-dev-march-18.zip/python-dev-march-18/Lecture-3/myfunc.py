

def mysum(a,b):
	c  = a+b
	return a+b

if __name__ == "__main__":
	print(mysum(1,2))
